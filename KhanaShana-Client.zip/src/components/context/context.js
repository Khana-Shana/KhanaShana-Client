import React, {createContext} from 'react';

const DiscountContext = createContext();

export default DiscountContext;