import React from 'react';
import LoginScreen from './loginscreen';

function Login(){
    return(
        <div>
            <LoginScreen/>
        </div>
    );
}

export default Login;